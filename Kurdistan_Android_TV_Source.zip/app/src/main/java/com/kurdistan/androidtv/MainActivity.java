package com.kurdistan.androidtv;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.text.InputType;
import java.net.*;
import java.io.*;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    LinearLayout root, toolbar, content, channelsBox;
    EditText playlistUrl, channelName, channelUrl;
    TextView status;
    ArrayList<Channel> channels = new ArrayList<>();
    String filter = "هەموو";
    final int BG=Color.rgb(8,14,26), PANEL=Color.rgb(19,31,50), GOLD=Color.rgb(242,193,93);
    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL); loadSaved(); build(); render();}
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density);}
    TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));d.setStroke(dp(1),Color.rgb(49,65,88));return d;}
    Button button(String s,Runnable r){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setTextSize(16);b.setBackground(bg(Color.rgb(35,51,75),10));b.setOnClickListener(v->r.run());b.setFocusable(true);return b;}
    EditText edit(String hint){EditText e=new EditText(this);e.setSingleLine(true);e.setTextColor(Color.WHITE);e.setHintTextColor(0xff9eabc0);e.setHint(hint);e.setTextSize(16);e.setPadding(dp(14),dp(8),dp(14),dp(8));e.setBackground(bg(Color.rgb(9,17,31),8));e.setSelectAllOnFocus(true);return e;}
    void build(){
        ScrollView scroll=new ScrollView(this); root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(28),dp(20),dp(28),dp(24));root.setBackgroundColor(BG);scroll.addView(root);setContentView(scroll);
        TextView brand=text("KURDISTAN TV  •  کەناڵە کوردی و وەرزشییەکان",25,GOLD);brand.setTypeface(null,1);root.addView(brand,new LinearLayout.LayoutParams(-1,dp(55)));
        TextView sub=text("پەخشی ڕاستەوخۆ بە سەرچاوەی ڕەسمی یان لیستی M3U",15,0xffb8c3d4);root.addView(sub);
        LinearLayout tabs=new LinearLayout(this);tabs.setOrientation(0);root.addView(tabs,new LinearLayout.LayoutParams(-1,dp(58)));
        for(String f:new String[]{"هەموو","کوردی","وەرزش","هەواڵ"}){Button b=button(f,()->{filter=f;render();});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(48),1);p.setMargins(dp(4),dp(5),dp(4),dp(5));tabs.addView(b,p);}
        TextView h=text("زیادکردنی لیستی M3U",20,GOLD);h.setPadding(0,dp(15),0,dp(5));root.addView(h);
        playlistUrl=edit("https://.../playlist.m3u");root.addView(playlistUrl,new LinearLayout.LayoutParams(-1,dp(52)));
        root.addView(button("بارکردنی لیست",()->loadPlaylist()),new LinearLayout.LayoutParams(-1,dp(52)));
        TextView add=text("یان زیادکردنی کەناڵێکی ڕەسمی بە بەستەر",18,GOLD);add.setPadding(0,dp(12),0,dp(5));root.addView(add);
        channelName=edit("ناوی کەناڵ");root.addView(channelName,new LinearLayout.LayoutParams(-1,dp(48)));
        channelUrl=edit("بەستەری ڕاستەوخۆی پەخش (HLS / MP4)");root.addView(channelUrl,new LinearLayout.LayoutParams(-1,dp(48)));
        root.addView(button("زیادکردنی کەناڵ",()->addChannel()),new LinearLayout.LayoutParams(-1,dp(50)));
        status=text("سەرچاوەی پەخشی خۆت زیاد بکە؛ هیچ کەناڵێک بەبێ مۆڵەت نیشان نادرێت.",14,0xffe6c77d);status.setPadding(0,dp(10),0,dp(8));root.addView(status);
        TextView listTitle=text("لیستی کەناڵەکان",22,Color.WHITE);listTitle.setPadding(0,dp(12),0,dp(8));root.addView(listTitle);
        channelsBox=new LinearLayout(this);channelsBox.setOrientation(1);root.addView(channelsBox);
    }
    boolean matches(Channel c){if(filter.equals("هەموو"))return true;String g=(c.group+" "+c.name).toLowerCase();if(filter.equals("وەرزش"))return g.contains("sport")||g.contains("sports")||g.contains("وەرزش")||g.contains("bein")||g.contains("ssc");if(filter.equals("هەواڵ"))return g.contains("news")||g.contains("هەواڵ");return g.contains("kurd")||g.contains("کورد")||g.contains("کوردی");}
    void render(){if(channelsBox==null)return;channelsBox.removeAllViews();int n=0;for(Channel c:channels){if(!matches(c))continue;n++;LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(12),dp(6),dp(12),dp(6));row.setBackground(bg(PANEL,12));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(66));rp.setMargins(0,dp(5),0,dp(5));channelsBox.addView(row,rp);
        TextView name=text("▶   "+c.name+"\\n"+c.group,17,Color.WHITE);row.addView(name,new LinearLayout.LayoutParams(0,-1,1));
        Button play=button("پەخش",()->{Intent i=new Intent(this,PlayerActivity.class);i.putExtra("name",c.name);i.putExtra("url",c.url);startActivity(i);});row.addView(play,new LinearLayout.LayoutParams(dp(100),dp(46)));
    }if(n==0){TextView empty=text("هێشتا کەناڵێک زیاد نەکراوە. M3U باربکە یان بەستەری ڕەسمی زیاد بکە.",16,0xffb8c3d4);empty.setPadding(dp(10),dp(20),dp(10),dp(20));channelsBox.addView(empty);}}
    void addChannel(){String n=channelName.getText().toString().trim(),u=channelUrl.getText().toString().trim();if(n.isEmpty()||!valid(u)){status.setText("ناوی کەناڵ و بەستەری دروست پێویستە.");return;}channels.add(new Channel(n,u,"کوردی / ڕەسمی"));save();channelName.setText("");channelUrl.setText("");status.setText("کەناڵ زیادکرا.");render();}
    boolean valid(String u){try{URL x=new URL(u);return x.getProtocol().equals("http")||x.getProtocol().equals("https");}catch(Exception e){return false;}}
    void loadPlaylist(){String u=playlistUrl.getText().toString().trim();if(!valid(u)){status.setText("تکایە بەستەرێکی HTTP/HTTPS بنووسە.");return;}status.setText("لیستەکە بار دەکرێت...");new Thread(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(12000);c.setReadTimeout(20000);c.setRequestProperty("User-Agent","KurdistanTV/1.0");BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream(),"UTF-8"));ArrayList<Channel> parsed=new ArrayList<>();String line, name=null, group="گشتی";while((line=r.readLine())!=null){line=line.trim();if(line.startsWith("#EXTINF")){int comma=line.lastIndexOf(',');name=comma>=0?line.substring(comma+1).trim():"کەناڵ";java.util.regex.Matcher m=java.util.regex.Pattern.compile("group-title=\\"([^\\"]*)\\"").matcher(line);group=m.find()?m.group(1):"گشتی";}else if(!line.isEmpty()&&!line.startsWith("#")&&name!=null){if(valid(line))parsed.add(new Channel(name,line,group));name=null;}}r.close();c.disconnect();runOnUiThread(()->{channels.addAll(parsed);save();status.setText(parsed.size()+" کەناڵ بارکرا.");render();});}catch(Exception e){runOnUiThread(()->status.setText("بارکردن نەکرا؛ بەستەر، CORS/ڕێگەپێدان یان ئینتەرنێت بپشکنە."));}}).start();}
    void save(){try{JSONArray a=new JSONArray();for(Channel c:channels){JSONObject o=new JSONObject();o.put("n",c.name);o.put("u",c.url);o.put("g",c.group);a.put(o);}getSharedPreferences("tv",0).edit().putString("channels",a.toString()).apply();}catch(Exception ignored){}}
    void loadSaved(){try{JSONArray a=new JSONArray(getSharedPreferences("tv",0).getString("channels","[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);channels.add(new Channel(o.getString("n"),o.getString("u"),o.optString("g","گشتی")));}}catch(Exception ignored){}}
}
