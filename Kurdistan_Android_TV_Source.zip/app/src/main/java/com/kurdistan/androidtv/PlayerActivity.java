package com.kurdistan.androidtv;
import android.app.*;import android.os.*;import android.view.*;import android.widget.*;import android.graphics.Color;
import androidx.media3.common.MediaItem;import androidx.media3.common.PlaybackException;import androidx.media3.common.Player;import androidx.media3.exoplayer.ExoPlayer;import androidx.media3.ui.PlayerView;
public class PlayerActivity extends Activity{
 ExoPlayer player;PlayerView view;
 @Override public void onCreate(Bundle b){super.onCreate(b);String url=getIntent().getStringExtra("url"),name=getIntent().getStringExtra("name");getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(Color.BLACK);TextView title=new TextView(this);title.setText(name==null?"پەخش":name);title.setTextColor(Color.WHITE);title.setTextSize(20);title.setPadding(20,10,20,10);root.addView(title);view=new PlayerView(this);view.setUseController(true);root.addView(view,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);player=new ExoPlayer.Builder(this).build();view.setPlayer(player);player.setMediaItem(MediaItem.fromUri(url));player.prepare();player.play();player.addListener(new Player.Listener(){@Override public void onPlayerError(PlaybackException e){title.setText("هەڵەی پەخش: "+e.getErrorCodeName());}});}
 @Override protected void onStop(){super.onStop();if(player!=null){player.release();player=null;}}
}
