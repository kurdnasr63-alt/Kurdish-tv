package com.kurdistan.androidtv;
public class Channel {
    public final String name, url, group;
    public Channel(String name, String url, String group) {
        this.name=name; this.url=url; this.group=group;
    }
}
