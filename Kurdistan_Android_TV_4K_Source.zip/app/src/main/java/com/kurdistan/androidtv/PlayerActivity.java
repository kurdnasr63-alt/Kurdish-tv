package com.kurdistan.androidtv;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;

import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector;
import androidx.media3.ui.PlayerView;

public class PlayerActivity extends Activity {
    private ExoPlayer player;
    private PlayerView playerView;
    private String streamUrl;
    private TextView status;
    private Button retryButton;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        streamUrl = getIntent().getStringExtra("url");
        String name = getIntent().getStringExtra("name");
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);

        TextView title = new TextView(this);
        title.setText((name == null ? "پەخش" : name) + "   •   Auto / تا 4K");
        title.setTextColor(Color.WHITE);
        title.setTextSize(19);
        title.setPadding(20, 10, 20, 6);
        root.addView(title);

        status = new TextView(this);
        status.setText("Auto چالاکە • لە 360p تا 4K، بە پێی سەرچاوە و ئینتەرنێت.");
        status.setTextColor(0xffe8c875);
        status.setTextSize(13);
        status.setPadding(20, 2, 20, 8);
        root.addView(status);

        playerView = new PlayerView(this);
        playerView.setUseController(true);
        root.addView(playerView, new LinearLayout.LayoutParams(-1, 0, 1));

        retryButton = new Button(this);
        retryButton.setText("دووبارە هەوڵدانەوەی پەخش");
        retryButton.setVisibility(View.GONE);
        retryButton.setOnClickListener(v -> startPlayback());
        root.addView(retryButton, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
        startPlayback();
    }

    private void startPlayback() {
        if (streamUrl == null || streamUrl.trim().isEmpty()) {
            status.setText("بەستەری پەخش بەردەست نییە.");
            retryButton.setVisibility(View.VISIBLE);
            return;
        }
        retryButton.setVisibility(View.GONE);
        status.setText("پەخش ئامادە دەکرێت... Auto / Adaptive Bitrate تا 4K");

        if (player != null) {
            player.release();
            player = null;
        }

        // DefaultTrackSelector uses adaptive track selection by default.
        // For HLS master playlists with multiple renditions, ExoPlayer switches
        // between available qualities according to measured bandwidth.
        DefaultTrackSelector trackSelector = new DefaultTrackSelector(this);
        // Allow adaptive playback up to UHD 4K. ExoPlayer still selects a
        // lower rendition automatically when bandwidth/device capability requires it.
        trackSelector.setParameters(
            trackSelector.buildUponParameters()
                .setMaxVideoSize(3840, 2160)
                .build()
        );

        // Moderate startup and rebuffer thresholds: balance startup time and
        // resilience on slower or unstable home internet connections.
        DefaultLoadControl loadControl = new DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                15000,  // minimum buffer
                60000,  // maximum buffer
                2500,   // buffer before first playback
                6000    // buffer after a rebuffer
            )
            .setPrioritizeTimeOverSizeThresholds(true)
            .build();

        player = new ExoPlayer.Builder(this)
            .setTrackSelector(trackSelector)
            .setLoadControl(loadControl)
            .build();
        playerView.setPlayer(player);
        player.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int playbackState) {
                if (playbackState == Player.STATE_BUFFERING) {
                    status.setText("چاوەڕوانی داتای پەخش... کوالیتی Auto");
                } else if (playbackState == Player.STATE_READY) {
                    status.setText("پەخش چالاکە • Auto / Adaptive Bitrate تا 4K");
                }
            }
            @Override public void onPlayerError(PlaybackException error) {
                status.setText("پەخش وەستا. بەستەر یان ئینتەرنێت بپشکنە.");
                retryButton.setVisibility(View.VISIBLE);
            }
        });
        player.setMediaItem(MediaItem.fromUri(streamUrl));
        player.prepare();
        player.play();
    }

    @Override protected void onStop() {
        super.onStop();
        if (player != null) {
            player.release();
            player = null;
        }
    }
}
